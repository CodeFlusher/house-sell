<template>
  <div class="flex">
    <SiteHeader class="fixed top-0 left-0 w-full h-16"/>
    <NuxtPage class="h-screen mt-16 "></NuxtPage>
  </div>
</template>

<style>
body{
  @apply bg-white dark:bg-neutral-900
}
</style>
<script setup lang="ts">
</script>