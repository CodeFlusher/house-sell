<template>
  <div class="h-full w-full flex flex-col">
    <SiteMainTitle/>
    <SiteMainTopBanner></SiteMainTopBanner>
  </div>
</template>

<script setup lang="ts">

</script>
