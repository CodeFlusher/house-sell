<script setup lang="ts">

</script>

<template>
  <span>
    ДОКТОР ПАРАФИН
  </span>
</template>

<style scoped>

</style>